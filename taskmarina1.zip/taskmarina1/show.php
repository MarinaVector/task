<?php
session_start();

if(!isset($_SESSION['user_id'])) { 
    header('Location: /login-form.php');
    exit;
}

$id = $_GET['id'];

//подготовка и выполнение запроса к БД
$pdo = new PDO('mysql:host=localhost;dbname=urok', 'root', '');
$sql = 'SELECT * from tasks where id=:id';
$statement = $pdo->prepare($sql);
$statement->execute([
  ':id'  =>  $id,
]);
$task = $statement->fetch(PDO::FETCH_ASSOC);


?>


<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">

  <title>Просмотр задачи</title>

  <!-- Bootstrap core CSS -->
  <link href="assets/css/bootstrap.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">

  <style>

  </style>
</head>

<body>
  <div class="form-wrapper text-center">

    <h1 class="h3 mb-3 font-weight-normal"><?php echo $task['title'];?></h1>
    <p class="mt-5 mb-3 text-muted"><?php echo $task['description'];?></p>

    <img src="/uploads/<?php echo $task['image'];?>" alt="" width="500" class="mb-3">


  </div>
</body>

</html>
